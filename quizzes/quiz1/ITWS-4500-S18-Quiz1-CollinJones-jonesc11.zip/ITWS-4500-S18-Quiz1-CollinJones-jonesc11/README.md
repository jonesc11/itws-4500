# Quiz 1 - Collin Jones - jonesc11

I made my application so that you could view the temperature status of multiple zip codes at one time. I did
this by making an AJAX call to my NodeJS application, and received a JSON object with the temperature for that
zip code. I the appended some text to a div below the text box. When the refresh button is pushed, the div is
simply cleared out.